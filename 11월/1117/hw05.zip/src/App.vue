<template>
  <div id="app">
    <nav-header></nav-header>
    <h2 class="text-center">사원 관리 시스템</h2>
    <router-view></router-view>
  </div>
</template>

<script>
import NavHeader from './components/NavHeader.vue'
export default {
  name: "app",
  components: {
   NavHeader
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
