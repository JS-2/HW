
<template>
    <div>
        <p>
      <router-link to="/">HOME</router-link>
      <router-link to="/hrmlist">목록</router-link>
    </p>  
    </div>
</template>